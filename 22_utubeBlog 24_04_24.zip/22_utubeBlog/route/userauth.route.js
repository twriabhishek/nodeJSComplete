const express = require("express");
const router = express.Router();
const multer = require("multer");
const path = require("path");
const {
  handleloginAuth,
  handlesignupAuth,
  handlelogoutAuth,
  handlecreateUpdate,
} = require("../controllers/userauth.controller");

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.resolve(`./public/userimage/`));
  },
  filename: function (req, file, cb) {
    return cb(null, `${Date.now()}-${file.originalname}`);
  },
});

const upload = multer({ storage: storage });
router.get("/login", (req, res) => {
  return res.render("login.ejs");
});

router.get("/signup", (req, res) => {
  return res.render("signup.ejs");
});

router.post("/login", handleloginAuth);
router.post("/signup", handlesignupAuth);
router.get("/logout", handlelogoutAuth);

router.post(
  "/CUuserDetail/:id",
  upload.single("userphoto"),
  handlecreateUpdate
);

module.exports = router;
